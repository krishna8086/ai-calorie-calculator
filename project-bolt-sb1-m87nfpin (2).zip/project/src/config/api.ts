export const API_CONFIG = {
  OPENAI_API_KEY: 'sk-dummy-key-replace-with-real-key',
  API_ENDPOINT: 'https://api.openai.com/v1/chat/completions',
  MODEL: 'gpt-3.5-turbo',
  MAX_TOKENS: 150,
  TEMPERATURE: 0.7,
};